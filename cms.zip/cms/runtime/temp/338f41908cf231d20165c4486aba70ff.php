<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"C:\Users\Administrator\Desktop\cms/application/admin\view\module\cp_category.html";i:1553921466;}*/ ?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>后台</title>
		<link rel="stylesheet" href="/public/static/admin/css/dashicons.css">
		<link rel="stylesheet" href="/public/static/admin/css/style.css">
		<script src="/public/static/admin/js/jquery.min.js"></script>
	</head>
	<body>
	<div class="wrap wrap-category">
		<h1>栏目管理</h1>
		<div class="tips"></div>
		<div class="box">
			<div class="box-body">
				<form method="post" action="<?php echo url('module/addCategory'); ?>">
					<table>
						<tr>
							<th width="84">显示顺序</th>
							<th>栏目名称</th
							><th width="120">操作</th>
						</tr>
						<?php echo $list; ?>
						<tr>
							<td colspan="3">
								<span class="jq-add s-add"><i class="icon-cross"></i><b>添加新栏目</b></span>
							</td>
						</tr>
						<tr class="s-act">
							<td colspan="3">
								<input type="submit" value="提交更改">
							</td>
						</tr>
					</table>
				</form>
			</div>
		</div>
	</div>
	<script>
	    (function () {
		   var add_id = 0; //保存ID计数
		   //添加新栏目
		   $(".jq-add").click(function () {
                 var id = $(this).data("id");
			  $(this).parents("tr").before(
				 '<tr class="hover">\
					 <td class="center">\
						<input type="text" class="s-num" name="add[' + add_id + '][sort]">\
					</td>\
					<td colspan="2">\
						<input type="text" name="add[' + add_id + '][category_name]">\
						<input type="hidden" name="add[' + add_id + '][parent_id]" value="0">\
						<b class="jq-cancel">取消</b>\
					</td>\
				</tr>');
				++add_id;
		   });
		   //添加子栏目
		   $(".jq-sub-add").click(function () {
			  var id = $(this).data("id");
			  $(this).parents("tr").before(
				 '<tr class="hover">\
						<td class="center">\
							<input type="text" class="s-num" name="add[' + add_id + '][sort]">\
						</td>\
						<td colspan="2">\
							<i class="icon-sub"></i>\
							<input type="text" name="add[' + add_id + '][category_name]">\
						<input type="hidden" name="add[' + add_id + '][parent_id]" value="'+id+'">\
							<b class="jq-cancel">取消</b>\
						</td>\
				</tr>');
			  	++add_id;
			});

				//取消添加
				$(document).on("click", ".jq-cancel", function () {
					$(this).parents("tr").remove();
				});
				//删除前提示
				$(".jq-del").click(function () {
				    var _this=this;
					var id= $(this).data('id');
				    if(!confirm("您确定要删除此栏目？"))return;
					$.ajax({
					    url:'<?php echo url("module/delCategory"); ?>',
					    type:'post',
					    data:{id:id},
					    dataType:'json',
					    success:function (res) {
                                 console.log(res);
                                 if(res.code==1){
							  if(res.data['pid']===0)
                                    	 $(_this).parents('tr').next().remove();
						   }
                                 $(_this).parents('tr').remove();
                             }
					});

				});
			})();
		</script>
	</body>
</html>