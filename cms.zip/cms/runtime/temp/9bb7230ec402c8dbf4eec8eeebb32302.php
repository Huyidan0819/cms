<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:77:"C:\Users\Administrator\Desktop\cms/application/admin\view\module\cp_user.html";i:1553927016;}*/ ?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>后台</title>
		<link rel="stylesheet" href="/public/static/admin/css/dashicons.css">
		<link rel="stylesheet" href="/public/static/admin/css/style.css">
		<script src="/public/static/admin/js/jquery.min.js"></script>
	</head>
	<body>

	<div class="wrap wrap-article">
		<h1>用户管理</h1>

		<div class="tips"></div>
		<div class="box">
			<div class="box-body">
				<table>
                         <tr>
                              <th width="20">id</th>
                              <th width="50">姓名</th>
                               <th width="70">个人邮箱</th>
                              <th width="50">权限</th>
                              <th width="80">最后登录时间</th>
                              <th width="80">更新时间</th>
                              <th width="100">操作</th>
                         </tr>
                         <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$user): $mod = ($i % 2 );++$i;?>
                         <tr>
                              <td><?php echo $user['id']; ?></td>
                              <td><?php echo $user['username']; ?></td>
                              <td><?php echo $user['email']; ?></td>
                              <td><?php echo $user['status']==100?"超级管理员":"普通管理员"; ?></td>
                              <td><?php echo date('Y-m-d H:i:s',strtotime($user['create_time'])); ?></td>
                              <td><?php echo date('Y-m-d H:i:s',strtotime($user['update_time'])); ?></td>
                              <td class="s-act">
                                   <a href="<?php echo url('module/delUser',['id'=>$user['id']]); ?>">编辑</a>
                                   <a href="#" class="jq-del">删除</a>
                              </td>
                         </tr>
                         <?php endforeach; endif; else: echo "" ;endif; ?>
                    </table>
			</div>
		</div>
		<div class="pagelist">
              <?php echo $list->render(); ?>
          </div>
	</div>
	<script>
	    (function () {
             //删除前提示
             $(".jq-del").click(function () {
                 var _this=this;
                 if(confirm("您确定要删除此文章？")){
                     $.ajax({
                         url:'<?php echo url('module/delUser',['id'=>$user['id']]); ?>',
                         type:'post',
                         success:function (res) {
                             console.log(res);
                             if(res.code==1){
                                   alert(res.msg);
                                 $(_this).parents('tr').remove();
                             }
                         }
                     });
                 }
             });
         })();
	</script>
	</body>
</html>