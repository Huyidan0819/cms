<?php
    /**
     * Created by PhpStorm.
     * Tp5cmsUser: Administrator
     * Date: 2019/3/6 0006
     * Time: 下午 3:03
     */

    namespace app\common\module;
    use think\Model;

    class Tp5cmsArticleInfo extends Model
    {
        protected $autoWriteTimestamp=false;
    }