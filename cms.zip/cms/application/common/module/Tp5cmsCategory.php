<?php
    /**
     * Created by PhpStorm.
     * Tp5cmsUser: Administrator
     * Date: 2019/3/6 0006
     * Time: 下午 3:03
     */

    namespace app\common\module;
    use think\Model;
    use SoftDelete;
    class Tp5cmsCategory extends  Model
    {
        use \traits\model\SoftDelete;
        protected static $deleteTime = 'delete_time';
        //关联文章表
        public function article()
        {
            return $this->hasMany('tp5cms_article','id','category_id');
        }
        public function ArticleKeywordRelation()
        {
            return $this->hasMany('tp5cms_articleKeywordRelation','id');
        }

    }