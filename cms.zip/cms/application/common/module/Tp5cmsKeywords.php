<?php
    /**
     * Created by PhpStorm.
     * Tp5cmsUser: Administrator
     * Date: 2019/3/6 0006
     * Time: 下午 3:03
     */

    namespace app\common\module;


    use think\Model;

    class Tp5cmsKeywords extends Model
    {
        protected $autoWriteTimestamp=false;
        #关联文章g关系表关键字
        public function articleKeywordRelation()
        {
            return $this->hasMany('tp5cms_article_keyword_relation','keyword_id','id');
        }

        /**
         * 给关键字表模型和文章主表建立一个关联关系
         * @return \think\model\relation\BelongsToMany
         */
        public function article()
        {
            return $this->belongsToMany('tp5cms_article','tp5cms_article_keyword_relation','article_id','keyword_id');
        }
    }