<?php
    /**
     * Created by PhpStorm.
     * Tp5cmsUser: Administrator
     * Date: 2019/3/2 0002
     * Time: 下午 7:08
     */
    namespace app\front\controller;
    use app\common\module\Tp5cmsArticle;
    use app\service\BaseController;
    class Home extends BaseController
    {
        public function index()
        {
            //通过模型获取文章所有数据
            $articleArr=Tp5cmsArticle::where('delete_time')
                ->order('id','asc')
                ->paginate(3);
            $this->assign(['list'=>$articleArr]);
            return $this->fetch();
        }
    }