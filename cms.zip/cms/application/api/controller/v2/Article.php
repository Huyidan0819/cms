<?php
/**
 * Created by PhpStorm.
 * Tp5cmsUser: Administrator
 * Date: 2019/3/14 0014
 * Time: 下午 3:02
 */

namespace app\api\controller\v2;

use think\Controller;

class Article extends Controller
{
    public function getArticleInfoById($id)
    {
        return ['aa','bb'];
    }
    
}