<?php
/**
 * Created by PhpStorm.
 * Tp5cmsUser: Administrator
 * Date: 2019/3/14 0014
 * Time: 下午 3:09
 */
return [
    // 默认输出类型
    'default_return_type'    => 'json',
];