<?php
    /**
     * Created by PhpStorm.
     * Tp5cmsUser: Administrator
     * Date: 2019/3/7 0007
     * Time: 上午 10:24
     */
    return [
        'paginate'=>[
            'type'      => '\paginate\BackendPage',
            'var_page'  => 'page',
            'list_rows' => 15]
    ];

