/*
SQLyog Ultimate v8.82 
MySQL - 5.5.60-log : Database - tpcms
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`tpcms` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `tpcms`;

/*Table structure for table `article` */

DROP TABLE IF EXISTS `article`;

CREATE TABLE `article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL COMMENT '内容标题',
  `author_id` smallint(5) unsigned NOT NULL COMMENT '作者id',
  `category_id` smallint(5) unsigned NOT NULL COMMENT '栏目id',
  `bw_num` int(11) DEFAULT NULL COMMENT '浏览次数',
  `status` tinyint(4) DEFAULT '0' COMMENT '状态 0-草稿 1-发布',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  `thumb_url` varchar(200) DEFAULT NULL COMMENT '封面图片地址',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8;

/*Data for the table `article` */

insert  into `article`(`id`,`title`,`author_id`,`category_id`,`bw_num`,`status`,`description`,`thumb_url`,`create_time`,`update_time`,`delete_time`) values (69,'快看！习近平参加福建代表团审议讲话金句',1,7,59,1,'hello world','20190311\\4bbd698cda31c9b8e702dc5220de4a39.jpg','2019-03-11 16:03:05','2019-03-11 16:03:05',NULL),(70,'政协十三届二次会议举行第三次全体会议  ',1,8,33,1,'政协十三届二次会议举行第三次全体会议  ','20190311\\b188aeadd456bbc445b8b51c0ad0233b.jpg','2019-03-11 16:03:25','2019-03-11 16:03:25',NULL),(71,'既是促进法也是保护法 敢于动真碰硬  ',1,5,37,1,'既是促进法也是保护法 敢于动真碰硬  ','20190311\\f148c2a1e22a61ec529dfc931c28dd37.jpg','2019-03-11 16:03:44','2019-03-11 16:03:44',NULL),(72,'环境部部长李干杰：不能风头一过就把环境保护放一边',1,5,21,1,'环境部部长李干杰：不能风头一过就把环境保护放一边','20190311\\d0c952215a48577ac03f520012822806.jpg','2019-03-11 16:04:10','2019-03-11 16:04:10',NULL),(73,'国家药监局局长：疫苗管理法草案正在起草',1,10,11,1,'国家药监局局长：疫苗管理法草案正在起草','20190311\\a4e304f614a280dc95f216e20a359d78.jpg','2019-03-11 16:04:29','2019-03-11 16:04:29',NULL),(74,'一带一路建设行稳致远 守护一江碧水 抗日英雄黄魂',1,9,17,1,'一带一路建设行稳致远 守护一江碧水 抗日英雄黄魂','20190311\\4b9e2413920298f854c4e9259f015479.jpg','2019-03-11 16:04:49','2019-03-13 19:19:09',NULL),(76,'小蝴蝶',1,1,8,1,'梵蒂冈水电费','20190313\\70ca9b74640ce2439d091413166777d3.jpg','2019-03-13 19:24:23','2019-03-13 19:24:23',NULL),(77,'七年两会，读懂习近平强军之喻',2,1,4,1,'七年两会，读懂习近平强军之喻','20190313\\247624f46ec11735f1e257a2bfa8a96a.jpg','2019-03-13 21:58:09','2019-03-13 21:58:09',NULL),(78,'燃爆！《中国军队一分钟》震撼来袭',2,10,1,1,'燃爆！《中国军队一分钟》震撼来袭','20190313\\f726ac512732ede55d02dd11769c7b07.jpg','2019-03-13 21:58:39','2019-03-13 21:58:39',NULL),(79,'一人一句话！今年两会，部长们作出了这些承诺',2,13,4,1,'一人一句话！今年两会，部长们作出了这些承诺','20190313\\c557a7fcb31c382c8759848ea0afc2f4.jpg','2019-03-13 21:59:03','2019-03-13 21:59:03',NULL),(83,'test',2,1,0,0,NULL,NULL,'2019-03-14 20:26:03','2019-03-14 20:26:03',NULL),(84,'小蝴蝶',1,1,0,1,'花港饭店','20190314\\18e8624307ce10d701f9e790dc877e61.jpg','2019-03-14 20:26:51','2019-03-14 20:26:51',NULL),(85,'PHP教程',1,1,0,1,'范德萨','20190314\\7b3c2286bab644d9578166311705ded6.jpg','2019-03-14 20:28:14','2019-03-14 20:28:14',NULL),(86,'php 怎么将字符转成数字_百度知道',1,6,0,1,'php 怎么将字符转成数字_百度知道','20190314\\c8f57637192482b24e6349722d44c86e.jpeg','2019-03-14 20:30:52','2019-03-14 20:30:52',NULL);

/*Table structure for table `article_info` */

DROP TABLE IF EXISTS `article_info`;

CREATE TABLE `article_info` (
  `aid` int(10) unsigned NOT NULL,
  `content` text,
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `article_info` */

insert  into `article_info`(`aid`,`content`) values (58,'<p>hello world</p>\r\n'),(59,'<p>PHP</p>\r\n'),(60,'<p>PHP</p>\r\n'),(61,'<p>PHP</p>\r\n'),(62,'<p>功夫大使馆点饭</p>\r\n'),(63,'<p>dgfs&nbsp;</p>\r\n'),(64,'<p>11111</p>\r\n'),(65,'<p>7777777</p>\r\n'),(66,'<p>房地产</p>\r\n'),(67,'<p>7887878</p>\r\n'),(68,'<p>割发代首第三方</p>\r\n'),(69,'<p>hello world</p>\r\n'),(70,'<p><strong><a href=\"http://paper.people.com.cn/rmrb/html/2019-03/11/nw.D110000renmrb_20190311_4-01.htm\" target=\"_blank\">政协十三届二次会议举行第三次全体会议</a>&nbsp;<em>&nbsp;</em></strong></p>\r\n'),(71,'<p><strong><a href=\"http://www.xinhuanet.com/2019-03/10/c_1124217266.htm\" target=\"_blank\">既是促进法也是保护法</a><em>&nbsp;</em><a href=\"http://www.xinhuanet.com/2019-03/10/c_1124217198.htm\" target=\"_blank\">敢于动真碰硬</a>&nbsp;<em>&nbsp;</em></strong></p>\r\n'),(72,'<ul>\r\n	<li><a href=\"https://www.thepaper.cn/newsDetail_forward_3113748\" target=\"_blank\">环境部部长李干杰：不能风头一过就把环境保护放一边</a></li>\r\n</ul>\r\n'),(73,'<ul>\r\n	<li><a href=\"http://baijiahao.baidu.com/s?id=1627677827389165486\" target=\"_blank\">国家药监局局长：疫苗管理法草案正在起草</a></li>\r\n</ul>\r\n'),(74,'<ul>\r\n	<li><a href=\"http://china.cnr.cn/news/20190311/t20190311_524537978.shtml\" target=\"_blank\">一带一路建设行稳致远</a>&nbsp;<a href=\"http://news.gmw.cn/2019-03/10/content_32621720.htm\" target=\"_blank\">守护一江碧水</a>&nbsp;<a href=\"http://news.gmw.cn/2019-03/11/content_32623784.htm\" target=\"_blank\">抗日英雄黄魂</a></li>\r\n</ul>\r\n'),(75,'<p>「ThinkPHP5开发连载92」tp5路由-路由参数</p>\r\n'),(76,'<p>割发代首地方</p>\r\n'),(77,'<p><strong><a href=\"http://news.cctv.com/2019/03/13/ARTI8PsCBFAn0LGxpHgGAfV6190313.shtml\" target=\"_blank\">七年两会，读懂习近平强军之喻</a></strong></p>\r\n'),(78,'<p><strong><a href=\"http://politics.gmw.cn/2019-03/13/content_32637522.htm\" target=\"_blank\">燃爆！《中国军队一分钟》震撼来袭</a></strong></p>\r\n'),(79,'<p><a href=\"http://baijiahao.baidu.com/s?id=1627887592304996433\" target=\"_blank\">一人一句话！今年两会，部长们作出了这些承诺</a></p>\r\n'),(81,NULL),(82,NULL),(83,NULL),(84,'<p>很反感的</p>\r\n'),(85,'<p>范德萨</p>\r\n'),(86,'<h3><a href=\"http://www.baidu.com/link?url=k1H2PH_PNFUcF5JuGJ8g88Ah5q8ZPuL_poHB6PLxUAzDJyVGDcf6VP_WGD2yskQEGiu6FnnNMIvuXsP7dRtyjdFXpZT0m1oZSDkdW92pw53\" target=\"_blank\"><em>php</em>&nbsp;怎么将字符转成<em>数字</em>_百度知道</a></h3>\r\n');

/*Table structure for table `article_keyword_relation` */

DROP TABLE IF EXISTS `article_keyword_relation`;

CREATE TABLE `article_keyword_relation` (
  `article_id` int(10) unsigned NOT NULL,
  `keyword_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `article_keyword_relation` */

insert  into `article_keyword_relation`(`article_id`,`keyword_id`) values (58,7),(58,15),(59,7),(65,7),(60,12),(66,16),(67,7),(68,12),(64,7),(61,7),(69,7),(70,7),(71,17),(72,7),(73,12),(74,8),(75,7),(76,7),(77,7),(78,18),(79,19),(81,20),(81,21),(82,20),(82,21),(83,20),(83,21),(84,7),(85,12),(86,22);

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL COMMENT '栏目名',
  `sort` int(11) DEFAULT NULL,
  `parent_id` smallint(6) NOT NULL COMMENT '父类id',
  `state` int(11) DEFAULT NULL,
  `total_rows` int(11) NOT NULL DEFAULT '0' COMMENT '文章总数',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

/*Data for the table `category` */

insert  into `category`(`id`,`category_name`,`sort`,`parent_id`,`state`,`total_rows`,`create_time`,`update_time`,`delete_time`) values (0,'无',0,32767,0,0,NULL,'2019-03-13 19:07:17','2019-03-13 19:07:17'),(1,'生活',1,0,1,44,NULL,'2019-03-08 17:36:40',NULL),(2,'资讯',2,0,1,0,NULL,NULL,NULL),(3,'编程',3,0,1,0,NULL,NULL,NULL),(4,'互联网',4,0,1,0,NULL,'2019-03-13 19:08:05',NULL),(5,'厨艺',1,1,1,7,NULL,'2019-03-08 17:36:21',NULL),(6,'时装',2,1,1,12,NULL,'2019-03-08 17:32:38',NULL),(7,'新闻资讯',1,2,1,0,NULL,NULL,NULL),(8,'学术观点',2,2,1,2,NULL,NULL,NULL),(9,'php',1,3,1,-1,NULL,NULL,NULL),(10,'Java',2,3,1,3,NULL,NULL,NULL),(11,'固元膏',3,4,1,1,'2019-03-09 14:40:26','2019-03-09 14:40:26',NULL),(12,'第三方',3,4,1,0,'2019-03-11 08:40:36','2019-03-13 21:59:20',NULL),(13,'菜鸟教程',3,4,1,0,'2019-03-13 17:28:13','2019-03-13 22:00:21',NULL);

/*Table structure for table `keywords` */

DROP TABLE IF EXISTS `keywords`;

CREATE TABLE `keywords` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `keyword` varchar(50) NOT NULL COMMENT '关键字',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

/*Data for the table `keywords` */

insert  into `keywords`(`id`,`keyword`,`create_time`,`delete_time`) values (7,'hello world','2019-03-06 21:27:27',NULL),(8,'PHP','2019-03-07 10:43:16',NULL),(9,'','2019-03-07 19:25:26',NULL),(10,'kkk','2019-03-08 09:11:46',NULL),(11,'lllll','2019-03-08 09:11:46',NULL),(12,'hello world，给一个一个','2019-03-08 16:16:46',NULL),(13,'hello world范德萨发','2019-03-08 16:18:28',NULL),(14,'PHP还不高一年级','2019-03-08 16:19:25',NULL),(15,'给一个一个','2019-03-08 16:25:56',NULL),(16,'房地产','2019-03-09 10:13:03',NULL),(17,'既是促进法也是保护法 敢于动真碰硬  ','2019-03-11 16:03:44',NULL),(18,'燃爆！《中国军队一分钟》震撼来袭','2019-03-13 21:58:39',NULL),(19,'一人一句话！今年两会，部长们作出了这些承诺','2019-03-13 21:59:03',NULL),(20,'121','2019-03-14 19:29:14',NULL),(21,'21','2019-03-14 19:29:15',NULL),(22,'php 怎么将字符转成数字_百度知道','2019-03-14 20:30:52',NULL);

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `access` int(11) DEFAULT NULL COMMENT '0-禁用 1-正常',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态 0-禁用',
  `salt` char(6) NOT NULL COMMENT '随机盐',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '编辑时间',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  `email` varchar(50) NOT NULL COMMENT '用户邮箱',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `user` */

insert  into `user`(`id`,`username`,`password`,`access`,`status`,`salt`,`create_time`,`update_time`,`delete_time`,`email`) values (1,'张三','be13b093d53644bc3b88dc76f278d574',1,100,'777','0000-00-00 00:00:00',NULL,NULL,'张三@qq.com'),(2,'admin','96f1fe34e2cb267a5c8f76653f424ebb',1,1,'888','0000-00-00 00:00:00',NULL,NULL,'admin@qq.com'),(6,'admin1','96f1fe34e2cb267a5c8f76653f424ebb',1,0,'888','2019-03-13 16:30:42','2019-03-30 04:56:20',NULL,'admin1@qq.com'),(8,'hhx999','be13b093d53644bc3b88dc76f278d574',1,1,'777','2019-03-13 19:19:44',NULL,NULL,'hhx999@qq.com'),(9,'111','96f1fe34e2cb267a5c8f76653f424ebb',0,1,'888','2019-03-13 19:20:18',NULL,NULL,'111@qq.com'),(10,'123','4297f44b13955235245b2497399d7a93',1,100,'123','0000-00-00 00:00:00',NULL,NULL,'123@qq.com');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
