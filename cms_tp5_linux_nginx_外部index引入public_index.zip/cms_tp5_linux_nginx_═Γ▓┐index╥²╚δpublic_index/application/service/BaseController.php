<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/3/6 0006
     * Time: 下午 2:11
     */

    namespace app\service;
    use think\Controller;

    class BaseController extends Controller
    {

    }